Pink Pass app package

This keeps the original Pink Pass artwork. To install as an iPhone Home Screen web app, upload the contents of this folder to an HTTPS static host (for example GitHub Pages), open the resulting URL in Safari, tap Share > Add to Home Screen, enable Open as Web App, then tap Add.

This is a web app, not an Apple Wallet .pkpass. Wallet passes must be signed with an Apple-issued Pass Type ID certificate.
